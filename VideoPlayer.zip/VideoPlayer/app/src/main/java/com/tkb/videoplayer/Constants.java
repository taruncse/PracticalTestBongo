package com.tkb.videoplayer;

public class Constants {
    public static String PLAY_TAG = "Play";
    public static String PAUSE_TAG = "Pause";

    public static String PLAY = "Playing...";
    public static String PAUSE = "Paused...";
    public static String REWIND = "Rewind...";
    public static String FORWARD = "Forward...";

}

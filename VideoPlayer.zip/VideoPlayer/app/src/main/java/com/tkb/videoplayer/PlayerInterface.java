package com.tkb.videoplayer;

public interface PlayerInterface {
    void play();
    void pause();
    void forward();
    void rewind();
}

package com.tkb.videoplayer;

public interface Update {
    void update(String value);
}
